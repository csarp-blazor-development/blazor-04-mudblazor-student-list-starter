﻿namespace Kreta.Shared.Enums
{
    public enum SchoolClassType { ClassA, ClassB, ClassC }
}
