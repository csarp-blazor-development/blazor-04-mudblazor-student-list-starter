﻿namespace Kreta.Shared.Models
{
    public class EducationLevels
    {
        public List<string> AllEducationLevels { get; } = new List<string> { "érettségi", "szakmai érettségi", "szakmai vizsga" };
    }
}
